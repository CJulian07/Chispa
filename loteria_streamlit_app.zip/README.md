
# Simulador de Lotería Inteligente (Streamlit)

Este proyecto simula combinaciones ganadoras basadas en resultados anteriores.

## Cómo usarlo en Streamlit Cloud

1. Sube este repositorio a tu GitHub.
2. Ve a [https://streamlit.io/cloud](https://streamlit.io/cloud)
3. Conéctalo con tu cuenta de GitHub.
4. Crea una nueva app seleccionando este repo.
5. Archivo principal: `app_loteria_streamlit.py`

## Requisitos del CSV

Debe contener columnas: R1, R2, R3, R4, R5 (con los números ganadores por fila).

